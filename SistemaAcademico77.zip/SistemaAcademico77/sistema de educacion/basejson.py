import json

class JsonFile:
    def __init__(self, filename):
        self.filename = filename

    def save(self, data):
        with open(self.filename, 'w', encoding='utf-8') as file:
            json.dump(data, file, indent=4, ensure_ascii=False)  # Añadido indent para una mejor legibilidad

    def read(self):
        try:
            with open(self.filename, 'r', encoding='utf-8') as file:
                data = json.load(file)
        except FileNotFoundError:
            data = []
        except json.JSONDecodeError:  # Añadido para manejar errores de decodificación JSON
            data = []
        return data

    def find(self, atributo, buscado):
        try:
            with open(self.filename, 'r', encoding='utf-8') as file:
                datas = json.load(file)
                data = [item for item in datas if item.get(atributo) == buscado]
        except FileNotFoundError:
            data = []
        except json.JSONDecodeError:  # Añadido para manejar errores de decodificación JSON
            data = []
        return data
