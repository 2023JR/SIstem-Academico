from iCrud import ICrud
from utilities import borrarPantalla, gotoxy, dibujar_cuadro
from basejson import JsonFile
import platform, time
import os
from datetime import date

path, _ = os.path.split(os.path.abspath(__file__))

class Matricula:
    def __init__(self, id, periodo, estudiante, active):
        self.id = id
        self.periodo = periodo
        self.estudiante = estudiante
        self.detalleMatricula = []
        self.fecha_creacion = date.today()
        self.active = active
    
    def addMatricula(self, detalle):
        self.detalleMatricula.append(detalle)

class DetalleMatricula:
    def __init__(self, id, asignatura, curso, profesor):
        self.id = id
        self.asignatura = asignatura
        self.curso = curso
        self.profesor = profesor

class CrudMatriculas(ICrud):
    @staticmethod
    def create():
        borrarPantalla()
        dibujar_cuadro()
        gotoxy(2, 1)
        print("Registro de Matrícula")
        gotoxy(2, 3)
        
        descripcion_curso = input("Ingrese la descripción del curso: ")
        codigo = input("Ingrese el código del curso: ")
        fecha_creacion = date.today().strftime("%Y-%m-%d")
        periodo = input("Ingrese el periodo de la matrícula: ")
        estudiante = input("Ingrese el nombre del estudiante: ")
        estado = input("Ingrese el estado de la matrícula (activo/inactivo): ").lower()

        json_file_materias = JsonFile(path + '/archivosbases/materias.json')
        materias = json_file_materias.read()
        
        print("Materias disponibles:")
        for materia in materias:
            print(f"ID: {materia['id']} - {materia['descripcion']}")
        ids_materias = input("Ingrese los IDs de las materias en las que el estudiante se registra, separadas por comas: ").split(',')
        ids_materias = [id_materia.strip() for id_materia in ids_materias]
        
        materias_seleccionadas = []
        for id_materia in ids_materias:
            try:
                id_materia_int = int(id_materia)
                if any(materia['id'] == id_materia_int for materia in materias):
                    materias_seleccionadas.append(next(materia for materia in materias if materia['id'] == id_materia_int))
                else:
                    print(f"ID de materia {id_materia_int} no encontrado.")
            except ValueError:
                print(f"ID de materia '{id_materia}' no es válido.")
        
        json_file_matriculas = JsonFile(path + '/archivosbases/matriculas.json')
        matriculas = json_file_matriculas.read()
        
        last_id = max([int(matriculas['id']) for matriculas in matriculas if matriculas['id'].isdigit()], default=0)
        new_id = last_id + 1
        
        nueva_matricula = Matricula(id=new_id, periodo=periodo, estudiante=estudiante, active=(estado == 'activo'))
        
        for materia in materias_seleccionadas:
            id_detalle = materia['id']
            detalle = DetalleMatricula(id=id_detalle, asignatura=materia['descripcion'], curso=descripcion_curso, profesor="Desconocido")
            nueva_matricula.addMatricula(detalle)
        
        matriculas.append(nueva_matricula.__dict__)
        json_file_matriculas.save(matriculas)
        print("Matrícula registrada exitosamente.")
        
        if platform.system() == 'Windows':
            input("Presione Enter para continuar...")
        else:
            time.sleep(2)


    
    @staticmethod
    def update():
        borrarPantalla()
        dibujar_cuadro()
        gotoxy(2, 1)
        print("Actualización de Matrícula")
        gotoxy(2, 3)
        
        json_file_matriculas = JsonFile(path + '/archivosbases/matriculas.json')
        matriculas = json_file_matriculas.read()
        
        id_matricula = int(input("Ingrese el ID de la matrícula que desea actualizar: "))
        matricula_data = next((m for m in matriculas if m['id'] == id_matricula), None)
        
        if matricula_data:
            matricula = Matricula(**matricula_data)
            print(f"Matrícula actual: {matricula.estudiante}, Estado: {'activo' if matricula.active else 'inactivo'}")
            nuevo_periodo = input("Ingrese el nuevo periodo (dejar vacío para no cambiar): ")
            nuevo_estado = input("Ingrese el nuevo estado (activo/inactivo) (dejar vacío para no cambiar): ")
            
            if nuevo_periodo:
                matricula.periodo = nuevo_periodo
            if nuevo_estado:
                matricula.active = nuevo_estado.lower() == 'activo'
            
            # Mostrar detalles actuales y seleccionar nuevas materias si se desea
            print("Detalles actuales:")
            for detalle in matricula.detalleMatricula:
                print(f"ID: {detalle.id} - Asignatura: {detalle.asignatura}, Curso: {detalle.curso}")
            
            modificar_detalles = input("¿Desea modificar los detalles de la matrícula? (s/n): ").lower()
            if modificar_detalles == 's':
                json_file_materias = JsonFile(path + '/archivosbases/materias.json')
                materias = json_file_materias.read()
                
                print("Materias disponibles:")
                for materia in materias:
                    print(f"ID: {materia['id']} - {materia['descripcion']}")
                ids_materias = input("Ingrese los IDs de las nuevas materias, separadas por comas: ").split(',')
                ids_materias = [int(id_materia.strip()) for id_materia in ids_materias]
                
                detalles_seleccionados = [DetalleMatricula(id=materia['id'], asignatura=materia['descripcion'], curso=matricula.descripcion_curso, profesor="Desconocido") for materia in materias if materia['id'] in ids_materias]
                matricula.detalleMatricula = detalles_seleccionados
            
            # Guardar cambios
            for i, m in enumerate(matriculas):
                if m['id'] == id_matricula:
                    matriculas[i] = matricula.__dict__
                    break
            json_file_matriculas.save(matriculas)
            print("Matrícula actualizada exitosamente.")
        else:
            print("Matrícula no encontrada.")
        
        if platform.system() == 'Windows':
            input("Presione Enter para continuar...")
        else:
            time.sleep(2)
    
    @staticmethod
    def delete():
        borrarPantalla()
        dibujar_cuadro()
        gotoxy(2, 1)
        print("Eliminación de Matrícula")
        gotoxy(2, 3)
        
        json_file_matriculas = JsonFile(path + '/archivosbases/matriculas.json')
        matriculas = json_file_matriculas.read()
        
        id_matricula = int(input("Ingrese el ID de la matrícula que desea eliminar: "))
        matricula = next((m for m in matriculas if m['id'] == id_matricula), None)
        
        if matricula:
            print(f"Matrícula encontrada: {matricula['estudiante']}")
            confirmacion = input("¿Está seguro de que desea eliminar esta matrícula? (s/n): ").lower()
            if confirmacion == 's':
                matriculas = [m for m in matriculas if m['id'] != id_matricula]
                json_file_matriculas.save(matriculas)
                print("Matrícula eliminada exitosamente.")
        else:
            print("Matrícula no encontrada.")
        
        if platform.system() == 'Windows':
            input("Presione Enter para continuar...")
        else:
            time.sleep(2)

    @staticmethod
    def consult():
        borrarPantalla()
        dibujar_cuadro()
        gotoxy(2, 1)
        print("Consulta de Matrícula")
        gotoxy(2, 3)
        
        json_file_matriculas = JsonFile(path + '/archivosbases/matriculas.json')
        matriculas = json_file_matriculas.read()
        
        id_matricula = int(input("Ingrese el ID de la matrícula que desea consultar: "))
        matricula_data = next((m for m in matriculas if m['id'] == id_matricula), None)
        
        if matricula_data:
            matricula = Matricula(**matricula_data)
            print(f"Periodo: {matricula.periodo}")
            print(f"Estudiante: {matricula.estudiante}")
            print(f"Fecha de creación: {matricula.fecha_creacion}")
            print(f"Estado: {'activo' if matricula.active else 'inactivo'}")
            print("Detalles de la matrícula:")
            for detalle in matricula.detalleMatricula:
                print(f"ID: {detalle.id} - Asignatura: {detalle.asignatura}, Curso: {detalle.curso}")
        else:
            print("Matrícula no encontrada.")
        
        if platform.system() == 'Windows':
            input("Presione Enter para continuar...")
        else:
            time.sleep(2)
